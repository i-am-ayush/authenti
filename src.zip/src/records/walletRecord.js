import immutable from 'immutable' 

const WalletRecord = immutable.Record({
    walletBalance: 0
})

export default WalletRecord